from flask import Flask, render_template, jsonify

app = Flask(__name__,template_folder = 'template')
HOSTELSS = [
  {
    'id' : 1,
    'title' : 'Hostel For Boys :- Oori , Adhiyaman , Kaari , Paari'
  },
  {
    'id' :2,
    'title': 'Hostel For Girls :- M Block , Kalpana Chawala Block,Senbagam Block, ESQ A Block , ESQ B Block, Meenakshi Hostel'
  }
]
@app.route("/")
def hello_world():
    return render_template('home.html',hostelss = HOSTELSS)

@app.route("/api/hostelss")
def list_jobs():
  return jsonify(HOSTELSS)

if __name__ == "__main__":
  app.run(host='0.0.0.0', debug = True)
  

  
